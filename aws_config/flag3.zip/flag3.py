import random

def lambda_handler(event, context): 
    # Lambda handler function.
    return {
        'statusCode': 200,
        'body': "SC4{0Nc3Y0uR_1n_tH3r2_N0_g01ng_bacK!}"
    }

